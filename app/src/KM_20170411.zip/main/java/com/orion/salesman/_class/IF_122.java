package com.orion.salesman._class;

/**
 * Created by maidinh on 4/10/2016.
 */
public interface IF_122 {
    void onSuccess();
    void onFail();
}
