package com.orion.salesman._infor._fragment._object;

import java.util.List;

/**
 * Created by maidinh on 31/10/2016.
 */
public class ListA0003 {
    List<ObjA0003>LIST;
    int RESULT;

    public List<ObjA0003> getLIST() {
        return LIST;
    }

    public void setLIST(List<ObjA0003> LIST) {
        this.LIST = LIST;
    }

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
