package com.orion.salesman._infor._fragment._object;

import java.util.List;

/**
 * Created by maidinh on 19/10/2016.
 */
public class ListOneNews {
    int RESULT;
    List<OneNew>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<OneNew> getLIST() {
        return LIST;
    }

    public void setLIST(List<OneNew> LIST) {
        this.LIST = LIST;
    }
}
