package com.orion.salesman._interface;

/**
 * Created by maidinh on 21/9/2016.
 */
public interface GetAddressCallback {
    void onSuccess(String s);
}
