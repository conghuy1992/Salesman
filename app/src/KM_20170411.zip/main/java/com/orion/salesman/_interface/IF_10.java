package com.orion.salesman._interface;

/**
 * Created by maidinh on 6/10/2016.
 */
public interface IF_10 {
    void onSuccess(String data);
    void onFail();
}
