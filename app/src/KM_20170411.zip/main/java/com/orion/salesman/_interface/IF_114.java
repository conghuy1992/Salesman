package com.orion.salesman._interface;

/**
 * Created by maidinh on 22/12/2016.
 */

public interface IF_114 {
    void onSuccess();
    void onFail();
}
