package com.orion.salesman._interface;

/**
 * Created by maidinh on 12/10/2016.
 */
public interface IF_117 {
    void onSuccess(String ID);
    void onFail();
}
