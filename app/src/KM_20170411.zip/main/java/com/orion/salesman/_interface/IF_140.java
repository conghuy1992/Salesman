package com.orion.salesman._interface;

import com.orion.salesman._object.Obj140;

import java.util.List;

/**
 * Created by maidinh on 16/12/2016.
 */

public interface IF_140 {
    void onSuccess(List<Obj140> LIST);
    void onFail();
}
