package com.orion.salesman._interface;

/**
 * Created by maidinh on 20/1/2017.
 */

public interface IF_DELETE_IMAGE {
    void onComplete(String result);
}
