package com.orion.salesman._object;

public class AddressSQLiteStreets {
    String IDX;
    String STREETCD;
    String STREETNM;

    public String getIDX() {
        return IDX;
    }

    public void setIDX(String IDX) {
        this.IDX = IDX;
    }

    public String getSTREETCD() {
        return STREETCD;
    }

    public void setSTREETCD(String STREETCD) {
        this.STREETCD = STREETCD;
    }

    public String getSTREETNM() {
        return STREETNM;
    }

    public void setSTREETNM(String STREETNM) {
        this.STREETNM = STREETNM;
    }
}
