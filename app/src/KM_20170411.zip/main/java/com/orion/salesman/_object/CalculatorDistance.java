package com.orion.salesman._object;

/**
 * Created by maidinh on 7/9/2016.
 */
public interface CalculatorDistance {
    void onCompleted(String s);
}
