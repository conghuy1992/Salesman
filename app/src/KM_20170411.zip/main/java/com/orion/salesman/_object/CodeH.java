package com.orion.salesman._object;

/**
 * Created by maidinh on 22/8/2016.
 */
public class CodeH {
    String IDX = "";
    String CODEGROUP = "";
    String CODEKEY = "";
    String CODEDESC = "";
    String CODEVALUE = "";
    String CODEVALUE2 = "";
    String CODEVALUE3 = "";
    String CODEVALUE4 = "";
    String CODEVALUE5 = "";
    String CODEVALUE6 = "";
    String GUBUN = "";
    String BIGO = "";
    String PLANTCD = "";

    public String getIDX() {
        return IDX;
    }

    public void setIDX(String IDX) {
        this.IDX = IDX;
    }

    public String getCODEGROUP() {
        return CODEGROUP;
    }

    public void setCODEGROUP(String CODEGROUP) {
        this.CODEGROUP = CODEGROUP;
    }

    public String getCODEKEY() {
        return CODEKEY;
    }

    public void setCODEKEY(String CODEKEY) {
        this.CODEKEY = CODEKEY;
    }

    public String getCODEDESC() {
        return CODEDESC;
    }

    public void setCODEDESC(String CODEDESC) {
        this.CODEDESC = CODEDESC;
    }

    public String getCODEVALUE() {
        return CODEVALUE;
    }

    public void setCODEVALUE(String CODEVALUE) {
        this.CODEVALUE = CODEVALUE;
    }

    public String getCODEVALUE2() {
        return CODEVALUE2;
    }

    public void setCODEVALUE2(String CODEVALUE2) {
        this.CODEVALUE2 = CODEVALUE2;
    }

    public String getCODEVALUE3() {
        return CODEVALUE3;
    }

    public void setCODEVALUE3(String CODEVALUE3) {
        this.CODEVALUE3 = CODEVALUE3;
    }

    public String getCODEVALUE4() {
        return CODEVALUE4;
    }

    public void setCODEVALUE4(String CODEVALUE4) {
        this.CODEVALUE4 = CODEVALUE4;
    }

    public String getCODEVALUE5() {
        return CODEVALUE5;
    }

    public void setCODEVALUE5(String CODEVALUE5) {
        this.CODEVALUE5 = CODEVALUE5;
    }

    public String getCODEVALUE6() {
        return CODEVALUE6;
    }

    public void setCODEVALUE6(String CODEVALUE6) {
        this.CODEVALUE6 = CODEVALUE6;
    }

    public String getGUBUN() {
        return GUBUN;
    }

    public void setGUBUN(String GUBUN) {
        this.GUBUN = GUBUN;
    }

    public String getBIGO() {
        return BIGO;
    }

    public void setBIGO(String BIGO) {
        this.BIGO = BIGO;
    }

    public String getPLANTCD() {
        return PLANTCD;
    }

    public void setPLANTCD(String PLANTCD) {
        this.PLANTCD = PLANTCD;
    }
}
