package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 16/9/2016.
 */
public class DATA_132 {
    int RESULT;
    List<list132> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<list132> getLIST() {
        return LIST;
    }

    public void setLIST(List<list132> LIST) {
        this.LIST = LIST;
    }
}
