package com.orion.salesman._object;

import com.orion.salesman._result._object.RouteNonShop;

import java.util.List;

/**
 * Created by maidinh on 14/9/2016.
 */
public class DATA_API_131 {
    int RESULT;
    List<RouteNonShop> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<RouteNonShop> getLIST() {
        return LIST;
    }

    public void setLIST(List<RouteNonShop> LIST) {
        this.LIST = LIST;
    }
}
