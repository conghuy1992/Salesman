package com.orion.salesman._object;

/**
 * Created by maidinh on 17/8/2016.
 */
public class DownData {
    String PDATYPE;

    public DownData(String PDATYPE) {
        this.PDATYPE = PDATYPE;
    }

    public String getPDATYPE() {
        return PDATYPE;
    }

    public void setPDATYPE(String PDATYPE) {
        this.PDATYPE = PDATYPE;
    }
}
