package com.orion.salesman._object;

/**
 * Created by maidinh on 21/10/2016.
 */
public class GET_DATA_INPUT {
    String VISIT="";
    String OMI="";
    String ORDER="";

    public String getVISIT() {
        return VISIT;
    }

    public void setVISIT(String VISIT) {
        this.VISIT = VISIT;
    }

    public String getOMI() {
        return OMI;
    }

    public void setOMI(String OMI) {
        this.OMI = OMI;
    }

    public String getORDER() {
        return ORDER;
    }

    public void setORDER(String ORDER) {
        this.ORDER = ORDER;
    }
}
