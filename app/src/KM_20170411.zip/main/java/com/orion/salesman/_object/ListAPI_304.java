package com.orion.salesman._object;

import java.util.List;

/**
 * Created by Huy on 17/9/2016.
 */
public class ListAPI_304 {
    int RESULT;
    List<Object_304>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<Object_304> getLIST() {
        return LIST;
    }

    public void setLIST(List<Object_304> LIST) {
        this.LIST = LIST;
    }
}
