package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 6/9/2016.
 */
public class ListSKUPromotion {
    int RESULT;
    List<SKUPromotion>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<SKUPromotion> getLIST() {
        return LIST;
    }

    public void setLIST(List<SKUPromotion> LIST) {
        this.LIST = LIST;
    }
}
