package com.orion.salesman._object;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by maidinh on 13/12/2016.
 */

public class ListSeBranch {
    List<SeBranch>LIST;
    int RESULT;

    public List<SeBranch> getLIST() {
        return LIST;
    }

    public void setLIST(List<SeBranch> LIST) {
        this.LIST = LIST;
    }

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
