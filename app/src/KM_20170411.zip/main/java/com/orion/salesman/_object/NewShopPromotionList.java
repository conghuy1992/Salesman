package com.orion.salesman._object;

/**
 * Created by maidinh on 7/9/2016.
 */
public class NewShopPromotionList {
    String V1;

    public String getV1() {
        return V1;
    }

    public void setV1(String v1) {
        V1 = v1;
    }
}
