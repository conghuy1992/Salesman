package com.orion.salesman._object;

/**
 * Created by maidinh on 26/10/2016.
 */
public class Obj_124 {
    String MODE;
    String CDATE;
    String DEALERCD;
    String CUSTCD;
    String PRDCD;
    String BOXQTY;
    String CASEQTY;
    String EAQTY;
    String PROBOXQTY;
    String PROCASEQTY;
    String PROEAQTY;
    String SIGNURL;

    public Obj_124(String MODE, String CDATE, String DEALERCD, String CUSTCD, String PRDCD, String BOXQTY,
                   String CASEQTY, String EAQTY, String PROBOXQTY, String PROCASEQTY, String PROEAQTY, String SIGNURL) {
        this.MODE = MODE;
        this.CDATE = CDATE;
        this.DEALERCD = DEALERCD;
        this.CUSTCD = CUSTCD;
        this.PRDCD = PRDCD;
        this.BOXQTY = BOXQTY;
        this.CASEQTY = CASEQTY;
        this.EAQTY = EAQTY;
        this.PROBOXQTY = PROBOXQTY;
        this.PROCASEQTY = PROCASEQTY;
        this.PROEAQTY = PROEAQTY;
        this.SIGNURL = SIGNURL;
    }

    public String getMODE() {
        return MODE;
    }

    public void setMODE(String MODE) {
        this.MODE = MODE;
    }

    public String getCDATE() {
        return CDATE;
    }

    public void setCDATE(String CDATE) {
        this.CDATE = CDATE;
    }

    public String getDEALERCD() {
        return DEALERCD;
    }

    public void setDEALERCD(String DEALERCD) {
        this.DEALERCD = DEALERCD;
    }

    public String getCUSTCD() {
        return CUSTCD;
    }

    public void setCUSTCD(String CUSTCD) {
        this.CUSTCD = CUSTCD;
    }

    public String getPRDCD() {
        return PRDCD;
    }

    public void setPRDCD(String PRDCD) {
        this.PRDCD = PRDCD;
    }

    public String getBOXQTY() {
        return BOXQTY;
    }

    public void setBOXQTY(String BOXQTY) {
        this.BOXQTY = BOXQTY;
    }

    public String getCASEQTY() {
        return CASEQTY;
    }

    public void setCASEQTY(String CASEQTY) {
        this.CASEQTY = CASEQTY;
    }

    public String getEAQTY() {
        return EAQTY;
    }

    public void setEAQTY(String EAQTY) {
        this.EAQTY = EAQTY;
    }

    public String getPROBOXQTY() {
        return PROBOXQTY;
    }

    public void setPROBOXQTY(String PROBOXQTY) {
        this.PROBOXQTY = PROBOXQTY;
    }

    public String getPROCASEQTY() {
        return PROCASEQTY;
    }

    public void setPROCASEQTY(String PROCASEQTY) {
        this.PROCASEQTY = PROCASEQTY;
    }

    public String getPROEAQTY() {
        return PROEAQTY;
    }

    public void setPROEAQTY(String PROEAQTY) {
        this.PROEAQTY = PROEAQTY;
    }

    public String getSIGNURL() {
        return SIGNURL;
    }

    public void setSIGNURL(String SIGNURL) {
        this.SIGNURL = SIGNURL;
    }
}
