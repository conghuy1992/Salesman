package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 5/9/2016.
 */
public class OrderNonShopListAPI {
    int RESULT;
    List<OrderNonShopList> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<OrderNonShopList> getLIST() {
        return LIST;
    }

    public void setLIST(List<OrderNonShopList> LIST) {
        this.LIST = LIST;
    }
}
