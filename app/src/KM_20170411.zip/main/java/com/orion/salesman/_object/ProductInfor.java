package com.orion.salesman._object;

/**
 * Created by maidinh on 18/8/2016.
 */
public class ProductInfor {
   String IDX;
   String TEAM;
    String PRDKIND;
    String PRDNM;
    String PRDCLS1;
    String BRANDNM;
    String TPRDCD;
    String TPRDDSC;
    String PRDCD;
    String PRDDSC;
    String CSEEAQTY;
    String BXCSEQTY;
    String BXEAQTY;
    String STOREPRICE;
    String STORECASEPRICE;
    String STOREEAPRICE;
    String BOXSALESYN;
    String CASESALESYN;
    String EASALESYN;

    public String getIDX() {
        return IDX;
    }

    public void setIDX(String IDX) {
        this.IDX = IDX;
    }

    public String getTEAM() {
        return TEAM;
    }

    public void setTEAM(String TEAM) {
        this.TEAM = TEAM;
    }

    public String getPRDKIND() {
        return PRDKIND;
    }

    public void setPRDKIND(String PRDKIND) {
        this.PRDKIND = PRDKIND;
    }

    public String getPRDNM() {
        return PRDNM;
    }

    public void setPRDNM(String PRDNM) {
        this.PRDNM = PRDNM;
    }

    public String getPRDCLS1() {
        return PRDCLS1;
    }

    public void setPRDCLS1(String PRDCLS1) {
        this.PRDCLS1 = PRDCLS1;
    }

    public String getBRANDNM() {
        return BRANDNM;
    }

    public void setBRANDNM(String BRANDNM) {
        this.BRANDNM = BRANDNM;
    }

    public String getTPRDCD() {
        return TPRDCD;
    }

    public void setTPRDCD(String TPRDCD) {
        this.TPRDCD = TPRDCD;
    }

    public String getTPRDDSC() {
        return TPRDDSC;
    }

    public void setTPRDDSC(String TPRDDSC) {
        this.TPRDDSC = TPRDDSC;
    }

    public String getPRDCD() {
        return PRDCD;
    }

    public void setPRDCD(String PRDCD) {
        this.PRDCD = PRDCD;
    }

    public String getPRDDSC() {
        return PRDDSC;
    }

    public void setPRDDSC(String PRDDSC) {
        this.PRDDSC = PRDDSC;
    }

    public String getCSEEAQTY() {
        return CSEEAQTY;
    }

    public void setCSEEAQTY(String CSEEAQTY) {
        this.CSEEAQTY = CSEEAQTY;
    }

    public String getBXCSEQTY() {
        return BXCSEQTY;
    }

    public void setBXCSEQTY(String BXCSEQTY) {
        this.BXCSEQTY = BXCSEQTY;
    }

    public String getBXEAQTY() {
        return BXEAQTY;
    }

    public void setBXEAQTY(String BXEAQTY) {
        this.BXEAQTY = BXEAQTY;
    }

    public String getSTOREPRICE() {
        return STOREPRICE;
    }

    public void setSTOREPRICE(String STOREPRICE) {
        this.STOREPRICE = STOREPRICE;
    }

    public String getSTORECASEPRICE() {
        return STORECASEPRICE;
    }

    public void setSTORECASEPRICE(String STORECASEPRICE) {
        this.STORECASEPRICE = STORECASEPRICE;
    }

    public String getSTOREEAPRICE() {
        return STOREEAPRICE;
    }

    public void setSTOREEAPRICE(String STOREEAPRICE) {
        this.STOREEAPRICE = STOREEAPRICE;
    }

    public String getBOXSALESYN() {
        return BOXSALESYN;
    }

    public void setBOXSALESYN(String BOXSALESYN) {
        this.BOXSALESYN = BOXSALESYN;
    }

    public String getCASESALESYN() {
        return CASESALESYN;
    }

    public void setCASESALESYN(String CASESALESYN) {
        this.CASESALESYN = CASESALESYN;
    }

    public String getEASALESYN() {
        return EASALESYN;
    }

    public void setEASALESYN(String EASALESYN) {
        this.EASALESYN = EASALESYN;
    }
}
