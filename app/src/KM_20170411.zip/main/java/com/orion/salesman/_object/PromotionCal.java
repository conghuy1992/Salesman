package com.orion.salesman._object;

/**
 * Created by huy on 10/10/2016.
 */

public class PromotionCal {
    String PDCODEGIFT = "";
    String UNIT = "";
    String TEXT = "";
    String S1 = "";

    public String getPDCODEGIFT() {

        return PDCODEGIFT;
    }

    public void setPDCODEGIFT(String PDCODEGIFT) {
        this.PDCODEGIFT = PDCODEGIFT;
    }

    public String getUNIT() {
        return UNIT;
    }

    public void setUNIT(String UNIT) {
        this.UNIT = UNIT;
    }

    public String getTEXT() {
        return TEXT;
    }

    public void setTEXT(String TEXT) {
        this.TEXT = TEXT;
    }

    public String getS1() {
        return S1;
    }

    public void setS1(String s1) {
        S1 = s1;
    }
}
