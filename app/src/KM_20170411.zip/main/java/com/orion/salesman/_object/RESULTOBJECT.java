package com.orion.salesman._object;

/**
 * Created by maidinh on 27/9/2016.
 */
public class RESULTOBJECT {
    int RESULT;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
