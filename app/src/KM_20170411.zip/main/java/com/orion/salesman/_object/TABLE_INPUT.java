package com.orion.salesman._object;

/**
 * Created by maidinh on 21/10/2016.
 */
public class TABLE_INPUT {
    int TABLE_INPUT_KEY = 0;
    String TABLE_INPUT_DATE = "";
    String TABLE_INPUT_SHOP_ID = "";
    String TABLE_INPUT_STOCK_PIE = "";
    String TABLE_INPUT_STOCK_SNACK = "";
    String TABLE_INPUT_STOCK_GUM = "";
    String TABLE_INPUT_DISPLAY_PIE = "";
    String TABLE_INPUT_DISPLAY_SNACK = "";
    String TABLE_INPUT_ORDER_PIE = "";
    String TABLE_INPUT_ORDER_SNACK = "";
    String TABLE_INPUT_ORDER_GUM = "";
    String TABLE_INPUT_OMI = "";
    String TABLE_INPUT_ORDER = "";
    String TABLE_INPUT_JSON_ORDER = "";

    public String getTABLE_INPUT_JSON_ORDER() {
        return TABLE_INPUT_JSON_ORDER;
    }

    public void setTABLE_INPUT_JSON_ORDER(String TABLE_INPUT_JSON_ORDER) {
        this.TABLE_INPUT_JSON_ORDER = TABLE_INPUT_JSON_ORDER;
    }

    public int getTABLE_INPUT_KEY() {
        return TABLE_INPUT_KEY;
    }

    public void setTABLE_INPUT_KEY(int TABLE_INPUT_KEY) {
        this.TABLE_INPUT_KEY = TABLE_INPUT_KEY;
    }

    public String getTABLE_INPUT_DATE() {
        return TABLE_INPUT_DATE;
    }

    public void setTABLE_INPUT_DATE(String TABLE_INPUT_DATE) {
        this.TABLE_INPUT_DATE = TABLE_INPUT_DATE;
    }

    public String getTABLE_INPUT_SHOP_ID() {
        return TABLE_INPUT_SHOP_ID;
    }

    public void setTABLE_INPUT_SHOP_ID(String TABLE_INPUT_SHOP_ID) {
        this.TABLE_INPUT_SHOP_ID = TABLE_INPUT_SHOP_ID;
    }

    public String getTABLE_INPUT_STOCK_PIE() {
        return TABLE_INPUT_STOCK_PIE;
    }

    public void setTABLE_INPUT_STOCK_PIE(String TABLE_INPUT_STOCK_PIE) {
        this.TABLE_INPUT_STOCK_PIE = TABLE_INPUT_STOCK_PIE;
    }

    public String getTABLE_INPUT_STOCK_SNACK() {
        return TABLE_INPUT_STOCK_SNACK;
    }

    public void setTABLE_INPUT_STOCK_SNACK(String TABLE_INPUT_STOCK_SNACK) {
        this.TABLE_INPUT_STOCK_SNACK = TABLE_INPUT_STOCK_SNACK;
    }

    public String getTABLE_INPUT_STOCK_GUM() {
        return TABLE_INPUT_STOCK_GUM;
    }

    public void setTABLE_INPUT_STOCK_GUM(String TABLE_INPUT_STOCK_GUM) {
        this.TABLE_INPUT_STOCK_GUM = TABLE_INPUT_STOCK_GUM;
    }

    public String getTABLE_INPUT_DISPLAY_PIE() {
        return TABLE_INPUT_DISPLAY_PIE;
    }

    public void setTABLE_INPUT_DISPLAY_PIE(String TABLE_INPUT_DISPLAY_PIE) {
        this.TABLE_INPUT_DISPLAY_PIE = TABLE_INPUT_DISPLAY_PIE;
    }

    public String getTABLE_INPUT_DISPLAY_SNACK() {
        return TABLE_INPUT_DISPLAY_SNACK;
    }

    public void setTABLE_INPUT_DISPLAY_SNACK(String TABLE_INPUT_DISPLAY_SNACK) {
        this.TABLE_INPUT_DISPLAY_SNACK = TABLE_INPUT_DISPLAY_SNACK;
    }

    public String getTABLE_INPUT_ORDER_PIE() {
        return TABLE_INPUT_ORDER_PIE;
    }

    public void setTABLE_INPUT_ORDER_PIE(String TABLE_INPUT_ORDER_PIE) {
        this.TABLE_INPUT_ORDER_PIE = TABLE_INPUT_ORDER_PIE;
    }

    public String getTABLE_INPUT_ORDER_SNACK() {
        return TABLE_INPUT_ORDER_SNACK;
    }

    public void setTABLE_INPUT_ORDER_SNACK(String TABLE_INPUT_ORDER_SNACK) {
        this.TABLE_INPUT_ORDER_SNACK = TABLE_INPUT_ORDER_SNACK;
    }

    public String getTABLE_INPUT_ORDER_GUM() {
        return TABLE_INPUT_ORDER_GUM;
    }

    public void setTABLE_INPUT_ORDER_GUM(String TABLE_INPUT_ORDER_GUM) {
        this.TABLE_INPUT_ORDER_GUM = TABLE_INPUT_ORDER_GUM;
    }

    public String getTABLE_INPUT_OMI() {
        return TABLE_INPUT_OMI;
    }

    public void setTABLE_INPUT_OMI(String TABLE_INPUT_OMI) {
        this.TABLE_INPUT_OMI = TABLE_INPUT_OMI;
    }

    public String getTABLE_INPUT_ORDER() {
        return TABLE_INPUT_ORDER;
    }

    public void setTABLE_INPUT_ORDER(String TABLE_INPUT_ORDER) {
        this.TABLE_INPUT_ORDER = TABLE_INPUT_ORDER;
    }
}
