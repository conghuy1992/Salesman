package com.orion.salesman._object;

/**
 * Created by maidinh on 9/9/2016.
 */
public interface UpPicture {
    void onSuccess();
    void onFail();
}
