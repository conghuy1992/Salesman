package com.orion.salesman._route._object;

/**
 * Created by maidinh on 4/8/2016.
 */
public class DisplayInfo {
    String V1;
    String V2;
    String V3;
    String V4;
    String V5;

    public DisplayInfo(String v1, String v2, String v3, String v4, String v5) {
        V1 = v1;
        V2 = v2;
        V3 = v3;
        V4 = v4;
        V5 = v5;
    }

    public String getV1() {
        return V1;
    }

    public void setV1(String v1) {
        V1 = v1;
    }

    public String getV2() {
        return V2;
    }

    public void setV2(String v2) {
        V2 = v2;
    }

    public String getV3() {
        return V3;
    }

    public void setV3(String v3) {
        V3 = v3;
    }

    public String getV4() {
        return V4;
    }

    public void setV4(String v4) {
        V4 = v4;
    }

    public String getV5() {
        return V5;
    }

    public void setV5(String v5) {
        V5 = v5;
    }
}
