package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 21/11/2016.
 */

public interface IF_128 {
    void onSuccess(List<ObjectA0128> list);
    void onFail();
}
