package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 17/8/2016.
 */
public class ListInforShop {
    int RESULT;
    List<InforShopDetails>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<InforShopDetails> getLIST() {
        return LIST;
    }

    public void setLIST(List<InforShopDetails> LIST) {
        this.LIST = LIST;
    }
}
