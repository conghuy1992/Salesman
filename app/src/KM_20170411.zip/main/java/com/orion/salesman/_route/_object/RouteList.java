package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 15/8/2016.
 */
public class RouteList {
    int RESULT;
    List<Route>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<Route> getLIST() {
        return LIST;
    }

    public void setLIST(List<Route> LIST) {
        this.LIST = LIST;
    }
}
