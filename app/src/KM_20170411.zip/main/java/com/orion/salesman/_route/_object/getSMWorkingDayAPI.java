package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 19/8/2016.
 */
public class getSMWorkingDayAPI {
    int RESULT;
    List<getSMWorkingDayObject>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<getSMWorkingDayObject> getLIST() {
        return LIST;
    }

    public void setLIST(List<getSMWorkingDayObject> LIST) {
        this.LIST = LIST;
    }
}
