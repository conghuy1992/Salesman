package com.orion.salesman._summary._object;

/**
 * Created by maidinh on 3/8/2016.
 */
public class SalesReport {
    String V0 = "";
    String V1 = "";
    String V2 = "";
    String V3 = "";
    String V4 = "";
    String V5 = "";
    String V6 = "";
    String V7 = "";
    String V8 = "";
    String V9 = "";
    String V12 = "";
    String V13 = "";
    String V14 = "";
    String V15 = "";
    String V16 = "";
    String KIND = "";

    public String getKIND() {
        return KIND;
    }

    public void setKIND(String KIND) {
        this.KIND = KIND;
    }

    public String getV13() {
        return V13;
    }

    public void setV13(String v13) {
        V13 = v13;
    }

    public String getV14() {
        return V14;
    }

    public void setV14(String v14) {
        V14 = v14;
    }

    public String getV15() {
        return V15;
    }

    public void setV15(String v15) {
        V15 = v15;
    }

    public String getV16() {
        return V16;
    }

    public void setV16(String v16) {
        V16 = v16;
    }

    public String getV12() {
        return V12;
    }

    public void setV12(String v12) {
        V12 = v12;
    }

    public void setShow(boolean show) {
        isShow = show;
    }

    public String getV0() {
        return V0;
    }

    public void setV0(String v0) {
        V0 = v0;
    }

    boolean isShow = false;

    public boolean isShow() {
        return isShow;
    }

    public void setIsShow(boolean isShow) {
        this.isShow = isShow;
    }

    public String getV9() {
        return V9;
    }

    public void setV9(String v9) {
        V9 = v9;
    }

    public String getV1() {
        return V1;
    }

    public void setV1(String v1) {
        V1 = v1;
    }

    public String getV2() {
        return V2;
    }

    public void setV2(String v2) {
        V2 = v2;
    }

    public String getV3() {
        return V3;
    }

    public void setV3(String v3) {
        V3 = v3;
    }

    public String getV4() {
        return V4;
    }

    public void setV4(String v4) {
        V4 = v4;
    }

    public String getV5() {
        return V5;
    }

    public void setV5(String v5) {
        V5 = v5;
    }

    public String getV6() {
        return V6;
    }

    public void setV6(String v6) {
        V6 = v6;
    }

    public String getV7() {
        return V7;
    }

    public void setV7(String v7) {
        V7 = v7;
    }

    public String getV8() {
        return V8;
    }

    public void setV8(String v8) {
        V8 = v8;
    }
}
