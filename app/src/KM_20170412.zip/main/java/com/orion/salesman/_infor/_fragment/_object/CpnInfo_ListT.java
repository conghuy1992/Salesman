package com.orion.salesman._infor._fragment._object;

/**
 * Created by maidinh on 1/11/2016.
 */
public class CpnInfo_ListT {
    String EMPID = "";
    String EMPNM = "";
    String POSITION = "";
    String BRANCHCD = "";
    String BRANCHNM = "";
    String DEPTCD = "";
    String DEPTNM = "";
    String BIRTH = "";
    String PHOTO = "";

    public String getEMPID() {
        return EMPID;
    }

    public void setEMPID(String EMPID) {
        this.EMPID = EMPID;
    }

    public String getEMPNM() {
        return EMPNM;
    }

    public void setEMPNM(String EMPNM) {
        this.EMPNM = EMPNM;
    }

    public String getPOSITION() {
        return POSITION;
    }

    public void setPOSITION(String POSITION) {
        this.POSITION = POSITION;
    }

    public String getBRANCHCD() {
        return BRANCHCD;
    }

    public void setBRANCHCD(String BRANCHCD) {
        this.BRANCHCD = BRANCHCD;
    }

    public String getBRANCHNM() {
        return BRANCHNM;
    }

    public void setBRANCHNM(String BRANCHNM) {
        this.BRANCHNM = BRANCHNM;
    }

    public String getDEPTCD() {
        return DEPTCD;
    }

    public void setDEPTCD(String DEPTCD) {
        this.DEPTCD = DEPTCD;
    }

    public String getDEPTNM() {
        return DEPTNM;
    }

    public void setDEPTNM(String DEPTNM) {
        this.DEPTNM = DEPTNM;
    }

    public String getBIRTH() {
        return BIRTH;
    }

    public void setBIRTH(String BIRTH) {
        this.BIRTH = BIRTH;
    }

    public String getPHOTO() {
        return PHOTO;
    }

    public void setPHOTO(String PHOTO) {
        this.PHOTO = PHOTO;
    }
}
