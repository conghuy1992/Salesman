package com.orion.salesman._infor._fragment._object;

import java.util.List;

/**
 * Created by maidinh on 28/10/2016.
 */
public class ListObjA0004 {
    int RESULT;
    List<ObjA0004> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<ObjA0004> getLIST() {
        return LIST;
    }

    public void setLIST(List<ObjA0004> LIST) {
        this.LIST = LIST;
    }
}
