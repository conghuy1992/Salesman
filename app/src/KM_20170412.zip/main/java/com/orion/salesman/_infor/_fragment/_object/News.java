package com.orion.salesman._infor._fragment._object;

/**
 * Created by maidinh on 4/10/2016.
 */
public class News {
    String S1;

    public News(String s1) {
        S1 = s1;
    }

    public News() {
    }

    public String getS1() {
        return S1;
    }

    public void setS1(String s1) {
        S1 = s1;
    }
}
