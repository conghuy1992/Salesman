package com.orion.salesman._infor._fragment._object;

import java.util.List;

/**
 * Created by maidinh on 1/11/2016.
 */
public interface OrionFamily {
    void onSuccess(List<CpnInfo_ListT> list);
    void onFail();
}
