package com.orion.salesman._interface;

/**
 * Created by huy on 27/08/2016.
 */
public interface DownloadDB  {
    void onSuccess();
}
