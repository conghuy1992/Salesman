package com.orion.salesman._interface;

/**
 * Created by maidinh on 5/9/2016.
 */
public interface DownloadOrderNonShop {
    void onSuccess();
}
