package com.orion.salesman._interface;

/**
 * Created by maidinh on 23/11/2016.
 */

public interface IF_129 {
    void onSuccess();
    void onFail();
}
