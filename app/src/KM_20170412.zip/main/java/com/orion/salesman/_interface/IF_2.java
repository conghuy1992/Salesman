package com.orion.salesman._interface;

/**
 * Created by maidinh on 19/10/2016.
 */
public interface IF_2 {
    void onSuccess(String s);
}
