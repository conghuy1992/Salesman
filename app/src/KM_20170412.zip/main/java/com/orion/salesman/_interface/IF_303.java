package com.orion.salesman._interface;

/**
 * Created by maidinh on 26/9/2016.
 */
public interface IF_303 {
    void onSuccess();
    void onFail();
}
