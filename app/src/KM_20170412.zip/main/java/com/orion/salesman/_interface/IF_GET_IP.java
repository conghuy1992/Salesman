package com.orion.salesman._interface;

/**
 * Created by maidinh on 12/12/2016.
 */

public interface IF_GET_IP {
    void onSuccess(String ip);
}
