package com.orion.salesman._interface;

import android.location.Location;

/**
 * Created by david on 10/20/15.
 */
public interface LocationChangeCallback {

    public void onLocationChangeCallBack(Location location);
}
