package com.orion.salesman._interface;

/**
 * Created by maidinh on 9/9/2016.
 */
public interface OnClickDialog {
    void btnOK();
    void btnCancel();

}
