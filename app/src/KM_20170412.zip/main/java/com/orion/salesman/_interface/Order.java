package com.orion.salesman._interface;

/**
 * Created by maidinh on 14/9/2016.
 */
public interface Order {
    void Success();
}
