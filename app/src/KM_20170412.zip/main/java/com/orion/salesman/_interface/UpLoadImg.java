package com.orion.salesman._interface;

/**
 * Created by maidinh on 29/9/2016.
 */
public interface UpLoadImg {
    void onSuccess(String s);
    void onFail(String s);
}
