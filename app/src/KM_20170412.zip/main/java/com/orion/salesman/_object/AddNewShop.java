package com.orion.salesman._object;

/**
 * Created by maidinh on 29/8/2016.
 */
public class AddNewShop {
    String MODE;
    String CDATETIME;
    String ROUTNO;
    String TEAMCD;
    String CUSTNM;
    String ADDR1;
    String ADDR2;
    String ADDR3;
    String ADDRSTR;
    String ADMINCODE;
    String HOUSENO;
    String GRADE;
    String OWNERNM;
    String HPNO;
    String CREATEDATE;
    String DEALERID;
    String DEALERNM;
    String CHANNEL;
    String LON;
    String LAT;
    String IMG1URL;
    String IMG2URL;
    String ENDDATE;
    String REASON;
    String ROUTSEQ;
    String CUSTCD;

    public String getCUSTCD() {
        return CUSTCD;
    }

    public void setCUSTCD(String CUSTCD) {
        this.CUSTCD = CUSTCD;
    }

    public String getROUTSEQ() {
        return ROUTSEQ;
    }

    public void setROUTSEQ(String ROUTSEQ) {
        this.ROUTSEQ = ROUTSEQ;
    }

    public String getMODE() {
        return MODE;
    }

    public void setMODE(String MODE) {
        this.MODE = MODE;
    }

    public String getCDATETIME() {
        return CDATETIME;
    }

    public void setCDATETIME(String CDATETIME) {
        this.CDATETIME = CDATETIME;
    }

    public String getROUTNO() {
        return ROUTNO;
    }

    public void setROUTNO(String ROUTNO) {
        this.ROUTNO = ROUTNO;
    }

    public String getTEAMCD() {
        return TEAMCD;
    }

    public void setTEAMCD(String TEAMCD) {
        this.TEAMCD = TEAMCD;
    }

    public String getCUSTNM() {
        return CUSTNM;
    }

    public void setCUSTNM(String CUSTNM) {
        this.CUSTNM = CUSTNM;
    }

    public String getADDR1() {
        return ADDR1;
    }

    public void setADDR1(String ADDR1) {
        this.ADDR1 = ADDR1;
    }

    public String getADDR2() {
        return ADDR2;
    }

    public void setADDR2(String ADDR2) {
        this.ADDR2 = ADDR2;
    }

    public String getADDR3() {
        return ADDR3;
    }

    public void setADDR3(String ADDR3) {
        this.ADDR3 = ADDR3;
    }

    public String getADDRSTR() {
        return ADDRSTR;
    }

    public void setADDRSTR(String ADDRSTR) {
        this.ADDRSTR = ADDRSTR;
    }

    public String getADMINCODE() {
        return ADMINCODE;
    }

    public void setADMINCODE(String ADMINCODE) {
        this.ADMINCODE = ADMINCODE;
    }

    public String getHOUSENO() {
        return HOUSENO;
    }

    public void setHOUSENO(String HOUSENO) {
        this.HOUSENO = HOUSENO;
    }

    public String getGRADE() {
        return GRADE;
    }

    public void setGRADE(String GRADE) {
        this.GRADE = GRADE;
    }

    public String getOWNERNM() {
        return OWNERNM;
    }

    public void setOWNERNM(String OWNERNM) {
        this.OWNERNM = OWNERNM;
    }

    public String getHPNO() {
        return HPNO;
    }

    public void setHPNO(String HPNO) {
        this.HPNO = HPNO;
    }

    public String getCREATEDATE() {
        return CREATEDATE;
    }

    public void setCREATEDATE(String CREATEDATE) {
        this.CREATEDATE = CREATEDATE;
    }

    public String getDEALERID() {
        return DEALERID;
    }

    public void setDEALERID(String DEALERID) {
        this.DEALERID = DEALERID;
    }

    public String getDEALERNM() {
        return DEALERNM;
    }

    public void setDEALERNM(String DEALERNM) {
        this.DEALERNM = DEALERNM;
    }

    public String getCHANNEL() {
        return CHANNEL;
    }

    public void setCHANNEL(String CHANNEL) {
        this.CHANNEL = CHANNEL;
    }

    public String getLON() {
        return LON;
    }

    public void setLON(String LON) {
        this.LON = LON;
    }

    public String getLAT() {
        return LAT;
    }

    public void setLAT(String LAT) {
        this.LAT = LAT;
    }

    public String getIMG1URL() {
        return IMG1URL;
    }

    public void setIMG1URL(String IMG1URL) {
        this.IMG1URL = IMG1URL;
    }

    public String getIMG2URL() {
        return IMG2URL;
    }

    public void setIMG2URL(String IMG2URL) {
        this.IMG2URL = IMG2URL;
    }

    public String getENDDATE() {
        return ENDDATE;
    }

    public void setENDDATE(String ENDDATE) {
        this.ENDDATE = ENDDATE;
    }

    public String getREASON() {
        return REASON;
    }

    public void setREASON(String REASON) {
        this.REASON = REASON;
    }
}
