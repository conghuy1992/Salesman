package com.orion.salesman._object;

/**
 * Created by maidinh on 16/8/2016.
 */
public class AddressSQLite {
    String IDX;
    String ADDR1;
    String ADDR2;
    String ADDR3;
    String ADDR4;
    String ADDR5;
    String ADDR6;
    String ADDR7;
    String ADDR8;
    String ADDR9;
//    String ADDR10;
//
//    public String getADDR10() {
//        return ADDR10;
//    }
//
//    public void setADDR10(String ADDR10) {
//        this.ADDR10 = ADDR10;
//    }

    public String getIDX() {
        return IDX;
    }

    public void setIDX(String IDX) {
        this.IDX = IDX;
    }

    public String getADDR1() {
        return ADDR1;
    }

    public void setADDR1(String ADDR1) {
        this.ADDR1 = ADDR1;
    }

    public String getADDR2() {
        return ADDR2;
    }

    public void setADDR2(String ADDR2) {
        this.ADDR2 = ADDR2;
    }

    public String getADDR3() {
        return ADDR3;
    }

    public void setADDR3(String ADDR3) {
        this.ADDR3 = ADDR3;
    }

    public String getADDR4() {
        return ADDR4;
    }

    public void setADDR4(String ADDR4) {
        this.ADDR4 = ADDR4;
    }

    public String getADDR5() {
        return ADDR5;
    }

    public void setADDR5(String ADDR5) {
        this.ADDR5 = ADDR5;
    }

    public String getADDR6() {
        return ADDR6;
    }

    public void setADDR6(String ADDR6) {
        this.ADDR6 = ADDR6;
    }

    public String getADDR7() {
        return ADDR7;
    }

    public void setADDR7(String ADDR7) {
        this.ADDR7 = ADDR7;
    }

    public String getADDR8() {
        return ADDR8;
    }

    public void setADDR8(String ADDR8) {
        this.ADDR8 = ADDR8;
    }

    public String getADDR9() {
        return ADDR9;
    }

    public void setADDR9(String ADDR9) {
        this.ADDR9 = ADDR9;
    }
}
