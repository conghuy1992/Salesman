package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 19/9/2016.
 */
public class DATA_303 {
    int RESULT;
    List<LIST_303> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<LIST_303> getLIST() {
        return LIST;
    }

    public void setLIST(List<LIST_303> LIST) {
        this.LIST = LIST;
    }
}
