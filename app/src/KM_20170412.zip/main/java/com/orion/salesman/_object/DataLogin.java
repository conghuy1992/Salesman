package com.orion.salesman._object;

/**
 * Created by maidinh on 9/8/2016.
 */
public class DataLogin {
    String DEPTCD = "";
    int GPSINTERVAL = 0;
    String HIDEPTCD = "";
    String IMGSERVERIP = "";
    String IMGSERVERPORT = "";
    String JOBCODE = "";
    String JOBNAME = "";
    String MNGEMPID = "";
    String PASSWORD = "";
    String PERSHORTDSC = "";
    String PUSHSERVERIP = "";
    String PUSHSERVERPORT = "";
    int RESULT = 0;
    String RETIREYN = "";
    String ROUTENO = "";
    String SALESMANTYPE = "";
    int SENDINTERVAL = 0;
    String TEAM = "";
    int USERID = 0;
    String USERNAME = "";
    int SEARCHINTERVAL = 0;
    String JOBGRADE = "";
    int CHECKSHOPDISTANCE = 0;
    String GPSSTARTTIME = "";
    String GPSENDTIME = "";
    String MAXSENDGPSCOUNT="";

    public String getMAXSENDGPSCOUNT() {
        return MAXSENDGPSCOUNT;
    }

    public void setMAXSENDGPSCOUNT(String MAXSENDGPSCOUNT) {
        this.MAXSENDGPSCOUNT = MAXSENDGPSCOUNT;
    }

    public String getGPSSTARTTIME() {
        return GPSSTARTTIME;
    }

    public void setGPSSTARTTIME(String GPSSTARTTIME) {
        this.GPSSTARTTIME = GPSSTARTTIME;
    }

    public String getGPSENDTIME() {
        return GPSENDTIME;
    }

    public void setGPSENDTIME(String GPSENDTIME) {
        this.GPSENDTIME = GPSENDTIME;
    }

    public int getCHECKSHOPDISTANCE() {
        return CHECKSHOPDISTANCE;
    }

    public void setCHECKSHOPDISTANCE(int CHECKSHOPDISTANCE) {
        this.CHECKSHOPDISTANCE = CHECKSHOPDISTANCE;
    }

    public String getJOBGRADE() {
        return JOBGRADE;
    }

    public void setJOBGRADE(String JOBGRADE) {
        this.JOBGRADE = JOBGRADE;
    }

    public int getSEARCHINTERVAL() {
        return SEARCHINTERVAL;
    }

    public void setSEARCHINTERVAL(int SEARCHINTERVAL) {
        this.SEARCHINTERVAL = SEARCHINTERVAL;
    }

    public String getTEAM() {
        return TEAM;
    }

    public void setTEAM(String TEAM) {
        this.TEAM = TEAM;
    }

    public String getDEPTCD() {
        return DEPTCD;
    }

    public void setDEPTCD(String DEPTCD) {
        this.DEPTCD = DEPTCD;
    }

    public int getGPSINTERVAL() {
        return GPSINTERVAL;
    }

    public void setGPSINTERVAL(int GPSINTERVAL) {
        this.GPSINTERVAL = GPSINTERVAL;
    }

    public String getHIDEPTCD() {
        return HIDEPTCD;
    }

    public void setHIDEPTCD(String HIDEPTCD) {
        this.HIDEPTCD = HIDEPTCD;
    }

    public String getIMGSERVERIP() {
        return IMGSERVERIP;
    }

    public void setIMGSERVERIP(String IMGSERVERIP) {
        this.IMGSERVERIP = IMGSERVERIP;
    }

    public String getIMGSERVERPORT() {
        return IMGSERVERPORT;
    }

    public void setIMGSERVERPORT(String IMGSERVERPORT) {
        this.IMGSERVERPORT = IMGSERVERPORT;
    }

    public String getJOBCODE() {
        return JOBCODE;
    }

    public void setJOBCODE(String JOBCODE) {
        this.JOBCODE = JOBCODE;
    }

    public String getJOBNAME() {
        return JOBNAME;
    }

    public void setJOBNAME(String JOBNAME) {
        this.JOBNAME = JOBNAME;
    }

    public String getMNGEMPID() {
        return MNGEMPID;
    }

    public void setMNGEMPID(String MNGEMPID) {
        this.MNGEMPID = MNGEMPID;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public String getPERSHORTDSC() {
        return PERSHORTDSC;
    }

    public void setPERSHORTDSC(String PERSHORTDSC) {
        this.PERSHORTDSC = PERSHORTDSC;
    }

    public String getPUSHSERVERIP() {
        return PUSHSERVERIP;
    }

    public void setPUSHSERVERIP(String PUSHSERVERIP) {
        this.PUSHSERVERIP = PUSHSERVERIP;
    }

    public String getPUSHSERVERPORT() {
        return PUSHSERVERPORT;
    }

    public void setPUSHSERVERPORT(String PUSHSERVERPORT) {
        this.PUSHSERVERPORT = PUSHSERVERPORT;
    }

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public String getRETIREYN() {
        return RETIREYN;
    }

    public void setRETIREYN(String RETIREYN) {
        this.RETIREYN = RETIREYN;
    }

    public String getROUTENO() {
        return ROUTENO;
    }

    public void setROUTENO(String ROUTENO) {
        this.ROUTENO = ROUTENO;
    }

    public String getSALESMANTYPE() {
        return SALESMANTYPE;
    }

    public void setSALESMANTYPE(String SALESMANTYPE) {
        this.SALESMANTYPE = SALESMANTYPE;
    }

    public int getSENDINTERVAL() {
        return SENDINTERVAL;
    }

    public void setSENDINTERVAL(int SENDINTERVAL) {
        this.SENDINTERVAL = SENDINTERVAL;
    }

    public int getUSERID() {
        return USERID;
    }

    public void setUSERID(int USERID) {
        this.USERID = USERID;
    }

    public String getUSERNAME() {
        return USERNAME;
    }

    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }
}
