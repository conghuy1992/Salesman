package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 17/8/2016.
 */
public class DownList {
    int RESULT;
    List<DownLoadObject>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<DownLoadObject> getLIST() {
        return LIST;
    }

    public void setLIST(List<DownLoadObject> LIST) {
        this.LIST = LIST;
    }
}
