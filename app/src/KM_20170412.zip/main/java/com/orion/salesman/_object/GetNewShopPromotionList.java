package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 7/9/2016.
 */
public class GetNewShopPromotionList {
    int RESULT;
    List<NewShopPromotionList> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<NewShopPromotionList> getLIST() {
        return LIST;
    }

    public void setLIST(List<NewShopPromotionList> LIST) {
        this.LIST = LIST;
    }
}
