package com.orion.salesman._object;

/**
 * Created by maidinh on 19/9/2016.
 */
public class LIST_303 {
    String V1;
    String V2;
    String V3;

    public String getV1() {
        return V1;
    }

    public void setV1(String v1) {
        V1 = v1;
    }

    public String getV2() {
        return V2;
    }

    public void setV2(String v2) {
        V2 = v2;
    }

    public String getV3() {
        return V3;
    }

    public void setV3(String v3) {
        V3 = v3;
    }
}
