package com.orion.salesman._object;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by maidinh on 8/11/2016.
 */
public class ListA0127 {
    int RESULT=0;
    ArrayList<ObjA0127>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public ArrayList<ObjA0127> getLIST() {
        return LIST;
    }

    public void setLIST(ArrayList<ObjA0127> LIST) {
        this.LIST = LIST;
    }
}
