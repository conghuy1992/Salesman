package com.orion.salesman._object;

/**
 * Created by maidinh on 18/10/2016.
 */
public class PARSE_117 {
    String MODE;
    String CDATETIME;
    String ROUTNO;
    String ROUTSEQ;
    String TEAMCD;
    String CUSTCD;
    String CUSTNM;
    String ADDR1;
    String ADDR2;
    String ADDR3;
    String ADDRSTR;
    String ADMINCODE;
    String HOUSENO;
    String GRADE;
    String OWNERNM;
    String HPNO;
    String CREATEDATE;
    String DEALERID;
    String DEALERNM;
    String CHANNEL;

    public String getMODE() {
        return MODE;
    }

    public void setMODE(String MODE) {
        this.MODE = MODE;
    }

    public String getCDATETIME() {
        return CDATETIME;
    }

    public void setCDATETIME(String CDATETIME) {
        this.CDATETIME = CDATETIME;
    }

    public String getROUTNO() {
        return ROUTNO;
    }

    public void setROUTNO(String ROUTNO) {
        this.ROUTNO = ROUTNO;
    }

    public String getROUTSEQ() {
        return ROUTSEQ;
    }

    public void setROUTSEQ(String ROUTSEQ) {
        this.ROUTSEQ = ROUTSEQ;
    }

    public String getTEAMCD() {
        return TEAMCD;
    }

    public void setTEAMCD(String TEAMCD) {
        this.TEAMCD = TEAMCD;
    }

    public String getCUSTCD() {
        return CUSTCD;
    }

    public void setCUSTCD(String CUSTCD) {
        this.CUSTCD = CUSTCD;
    }

    public String getCUSTNM() {
        return CUSTNM;
    }

    public void setCUSTNM(String CUSTNM) {
        this.CUSTNM = CUSTNM;
    }

    public String getADDR1() {
        return ADDR1;
    }

    public void setADDR1(String ADDR1) {
        this.ADDR1 = ADDR1;
    }

    public String getADDR2() {
        return ADDR2;
    }

    public void setADDR2(String ADDR2) {
        this.ADDR2 = ADDR2;
    }

    public String getADDR3() {
        return ADDR3;
    }

    public void setADDR3(String ADDR3) {
        this.ADDR3 = ADDR3;
    }

    public String getADDRSTR() {
        return ADDRSTR;
    }

    public void setADDRSTR(String ADDRSTR) {
        this.ADDRSTR = ADDRSTR;
    }

    public String getADMINCODE() {
        return ADMINCODE;
    }

    public void setADMINCODE(String ADMINCODE) {
        this.ADMINCODE = ADMINCODE;
    }

    public String getHOUSENO() {
        return HOUSENO;
    }

    public void setHOUSENO(String HOUSENO) {
        this.HOUSENO = HOUSENO;
    }

    public String getGRADE() {
        return GRADE;
    }

    public void setGRADE(String GRADE) {
        this.GRADE = GRADE;
    }

    public String getOWNERNM() {
        return OWNERNM;
    }

    public void setOWNERNM(String OWNERNM) {
        this.OWNERNM = OWNERNM;
    }

    public String getHPNO() {
        return HPNO;
    }

    public void setHPNO(String HPNO) {
        this.HPNO = HPNO;
    }

    public String getCREATEDATE() {
        return CREATEDATE;
    }

    public void setCREATEDATE(String CREATEDATE) {
        this.CREATEDATE = CREATEDATE;
    }

    public String getDEALERID() {
        return DEALERID;
    }

    public void setDEALERID(String DEALERID) {
        this.DEALERID = DEALERID;
    }

    public String getDEALERNM() {
        return DEALERNM;
    }

    public void setDEALERNM(String DEALERNM) {
        this.DEALERNM = DEALERNM;
    }

    public String getCHANNEL() {
        return CHANNEL;
    }

    public void setCHANNEL(String CHANNEL) {
        this.CHANNEL = CHANNEL;
    }
}
