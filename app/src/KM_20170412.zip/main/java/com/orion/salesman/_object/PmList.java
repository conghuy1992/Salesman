package com.orion.salesman._object;

import java.util.List;

/**
 * Created by maidinh on 6/9/2016.
 */
public class PmList {
    int RESULT;
    List<PMPRODUCTLIST>PMLIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<PMPRODUCTLIST> getPMLIST() {
        return PMLIST;
    }

    public void setPMLIST(List<PMPRODUCTLIST> PMLIST) {
        this.PMLIST = PMLIST;
    }
}
