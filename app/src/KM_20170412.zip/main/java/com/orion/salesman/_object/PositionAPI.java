package com.orion.salesman._object;

/**
 * Created by maidinh on 23/8/2016.
 */
public class PositionAPI {
    int RESULT;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
