package com.orion.salesman._object;

/**
 * Created by maidinh on 10/10/2016.
 */
public class RESENDNEWSHOP {
    int ID = 0;
    String DATA = "";

    public RESENDNEWSHOP() {
    }

    public RESENDNEWSHOP(String DATA) {
        this.DATA = DATA;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getDATA() {
        return DATA;
    }

    public void setDATA(String DATA) {
        this.DATA = DATA;
    }
}
