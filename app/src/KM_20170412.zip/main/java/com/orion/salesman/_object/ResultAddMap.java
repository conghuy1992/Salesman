package com.orion.salesman._object;

/**
 * Created by maidinh on 30/8/2016.
 */
public class ResultAddMap {
    int RESULT;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
