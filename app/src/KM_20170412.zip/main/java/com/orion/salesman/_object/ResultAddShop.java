package com.orion.salesman._object;

/**
 * Created by maidinh on 29/8/2016.
 */
public class ResultAddShop {
    int RESULT;
    String CUSTCD;

    public String getCUSTCD() {
        return CUSTCD;
    }

    public void setCUSTCD(String CUSTCD) {
        this.CUSTCD = CUSTCD;
    }

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
