package com.orion.salesman._object;

/**
 * Created by maidinh on 29/8/2016.
 */
public class RouteScheduleShop {
    String DATE;
    String WKDAY;

    public String getDATE() {
        return DATE;
    }

    public void setDATE(String DATE) {
        this.DATE = DATE;
    }

    public String getWKDAY() {
        return WKDAY;
    }

    public void setWKDAY(String WKDAY) {
        this.WKDAY = WKDAY;
    }
}
