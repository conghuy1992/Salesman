package com.orion.salesman._object;

/**
 * Created by maidinh on 18/8/2016.
 */
public class TeamDisplay {
    String IDX;
    String TEAMCD;
    String TEAMNM;
    String TOOLCD;
    String TOOLNM;
    String BRAND;
    String CHECKTOOKQTY;
    String CHECKSHOPQTY;

    public String getIDX() {
        return IDX;
    }

    public void setIDX(String IDX) {
        this.IDX = IDX;
    }

    public String getTEAMCD() {
        return TEAMCD;
    }

    public void setTEAMCD(String TEAMCD) {
        this.TEAMCD = TEAMCD;
    }

    public String getTEAMNM() {
        return TEAMNM;
    }

    public void setTEAMNM(String TEAMNM) {
        this.TEAMNM = TEAMNM;
    }

    public String getTOOLCD() {
        return TOOLCD;
    }

    public void setTOOLCD(String TOOLCD) {
        this.TOOLCD = TOOLCD;
    }

    public String getTOOLNM() {
        return TOOLNM;
    }

    public void setTOOLNM(String TOOLNM) {
        this.TOOLNM = TOOLNM;
    }

    public String getBRAND() {
        return BRAND;
    }

    public void setBRAND(String BRAND) {
        this.BRAND = BRAND;
    }

    public String getCHECKTOOKQTY() {
        return CHECKTOOKQTY;
    }

    public void setCHECKTOOKQTY(String CHECKTOOKQTY) {
        this.CHECKTOOKQTY = CHECKTOOKQTY;
    }

    public String getCHECKSHOPQTY() {
        return CHECKSHOPQTY;
    }

    public void setCHECKSHOPQTY(String CHECKSHOPQTY) {
        this.CHECKSHOPQTY = CHECKSHOPQTY;
    }
}
