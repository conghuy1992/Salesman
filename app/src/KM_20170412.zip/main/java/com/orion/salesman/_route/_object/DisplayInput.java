package com.orion.salesman._route._object;

/**
 * Created by maidinh on 30/8/2016.
 */
public class DisplayInput {
    String CDATE;
    String CUSTCD;
    String TOOLCD;
    String TOOLQTY;
    String MNGEMPID;

    public String getCDATE() {
        return CDATE;
    }

    public void setCDATE(String CDATE) {
        this.CDATE = CDATE;
    }

    public String getCUSTCD() {
        return CUSTCD;
    }

    public void setCUSTCD(String CUSTCD) {
        this.CUSTCD = CUSTCD;
    }

    public String getTOOLCD() {
        return TOOLCD;
    }

    public void setTOOLCD(String TOOLCD) {
        this.TOOLCD = TOOLCD;
    }

    public String getTOOLQTY() {
        return TOOLQTY;
    }

    public void setTOOLQTY(String TOOLQTY) {
        this.TOOLQTY = TOOLQTY;
    }

    public String getMNGEMPID() {
        return MNGEMPID;
    }

    public void setMNGEMPID(String MNGEMPID) {
        this.MNGEMPID = MNGEMPID;
    }
}
