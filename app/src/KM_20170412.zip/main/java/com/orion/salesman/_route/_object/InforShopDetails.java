package com.orion.salesman._route._object;

/**
 * Created by maidinh on 17/8/2016.
 */
public class InforShopDetails {
    String V1 = "";
    String V2 = "0";
    String V3 = "";
    String V4 = "";
    String V5 = "";
    String V6 = "";
    String V7 = "";
    String V8 = "";
    String V9 = "";
    String V10 = "";
    String V11 = "";
    String V12 = "";
    String V13 = "";
    String V14 = "0.0";
    String V15 = "0.0";
    String V16 = "";
    String V17 = "";
    String V18 = "";
    String V19 = "";
    String V20 = "0.0";
    String V21 = "0.0";
    String V22 = "0.0";
    String V23 = "0.0";
    String V24 = "0.0";
    String V25 = "0.0";
    String V26 = "";
    String V27 = "";
    String V28 = "";
    String V29 = "";
    String V30 = "";
    String V31 = "";

    public String getV31() {
        return V31;
    }

    public void setV31(String v31) {
        V31 = v31;
    }

    public String getV1() {
        return V1;
    }

    public void setV1(String v1) {
        V1 = v1;
    }

    public String getV2() {
        return V2;
    }

    public void setV2(String v2) {
        V2 = v2;
    }

    public String getV3() {
        return V3;
    }

    public void setV3(String v3) {
        V3 = v3;
    }

    public String getV4() {
        return V4;
    }

    public void setV4(String v4) {
        V4 = v4;
    }

    public String getV5() {
        return V5;
    }

    public void setV5(String v5) {
        V5 = v5;
    }

    public String getV6() {
        return V6;
    }

    public void setV6(String v6) {
        V6 = v6;
    }

    public String getV7() {
        return V7;
    }

    public void setV7(String v7) {
        V7 = v7;
    }

    public String getV8() {
        return V8;
    }

    public void setV8(String v8) {
        V8 = v8;
    }

    public String getV9() {
        return V9;
    }

    public void setV9(String v9) {
        V9 = v9;
    }

    public String getV10() {
        return V10;
    }

    public void setV10(String v10) {
        V10 = v10;
    }

    public String getV11() {
        return V11;
    }

    public void setV11(String v11) {
        V11 = v11;
    }

    public String getV12() {
        return V12;
    }

    public void setV12(String v12) {
        V12 = v12;
    }

    public String getV13() {
        return V13;
    }

    public void setV13(String v13) {
        V13 = v13;
    }

    public String getV14() {
        return V14;
    }

    public void setV14(String v14) {
        V14 = v14;
    }

    public String getV15() {
        return V15;
    }

    public void setV15(String v15) {
        V15 = v15;
    }

    public String getV16() {
        return V16;
    }

    public void setV16(String v16) {
        V16 = v16;
    }

    public String getV17() {
        return V17;
    }

    public void setV17(String v17) {
        V17 = v17;
    }

    public String getV18() {
        return V18;
    }

    public void setV18(String v18) {
        V18 = v18;
    }

    public String getV19() {
        return V19;
    }

    public void setV19(String v19) {
        V19 = v19;
    }

    public String getV20() {
        return V20;
    }

    public void setV20(String v20) {
        V20 = v20;
    }

    public String getV21() {
        return V21;
    }

    public void setV21(String v21) {
        V21 = v21;
    }

    public String getV22() {
        return V22;
    }

    public void setV22(String v22) {
        V22 = v22;
    }

    public String getV23() {
        return V23;
    }

    public void setV23(String v23) {
        V23 = v23;
    }

    public String getV24() {
        return V24;
    }

    public void setV24(String v24) {
        V24 = v24;
    }

    public String getV25() {
        return V25;
    }

    public void setV25(String v25) {
        V25 = v25;
    }

    public String getV26() {
        return V26;
    }

    public void setV26(String v26) {
        V26 = v26;
    }

    public String getV27() {
        return V27;
    }

    public void setV27(String v27) {
        V27 = v27;
    }

    public String getV28() {
        return V28;
    }

    public void setV28(String v28) {
        V28 = v28;
    }

    public String getV29() {
        return V29;
    }

    public void setV29(String v29) {
        V29 = v29;
    }

    public String getV30() {
        return V30;
    }

    public void setV30(String v30) {
        V30 = v30;
    }
}
