package com.orion.salesman._route._object;

/**
 * Created by maidinh on 30/8/2016.
 */
public class InputStock {
    int RESULT;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
