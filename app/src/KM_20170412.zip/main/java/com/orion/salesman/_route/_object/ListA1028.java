package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 21/11/2016.
 */

public class ListA1028 {
    List<ObjectA0128>LIST;
    int RESULT;

    public List<ObjectA0128> getLIST() {
        return LIST;
    }

    public void setLIST(List<ObjectA0128> LIST) {
        this.LIST = LIST;
    }

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }
}
