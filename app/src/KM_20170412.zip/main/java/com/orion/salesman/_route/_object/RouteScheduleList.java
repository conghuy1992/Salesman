package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 17/8/2016.
 */
public class RouteScheduleList {
    int RESULT;
    List<DisplayInfo> LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<DisplayInfo> getLIST() {
        return LIST;
    }

    public void setLIST(List<DisplayInfo> LIST) {
        this.LIST = LIST;
    }
}
