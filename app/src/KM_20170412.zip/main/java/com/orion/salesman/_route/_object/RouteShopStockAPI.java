package com.orion.salesman._route._object;

/**
 * Created by maidinh on 19/8/2016.
 */
public class RouteShopStockAPI {
    String WKDAY;

    public RouteShopStockAPI(String WKDAY) {
        this.WKDAY = WKDAY;
    }

    public String getWKDAY() {
        return WKDAY;
    }

    public void setWKDAY(String WKDAY) {
        this.WKDAY = WKDAY;
    }
}
