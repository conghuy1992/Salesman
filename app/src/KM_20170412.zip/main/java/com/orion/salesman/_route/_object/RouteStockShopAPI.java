package com.orion.salesman._route._object;

import java.util.List;

/**
 * Created by maidinh on 19/8/2016.
 */
public class RouteStockShopAPI {
    int RESULT;
    List<RouteStockShop>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<RouteStockShop> getLIST() {
        return LIST;
    }

    public void setLIST(List<RouteStockShop> LIST) {
        this.LIST = LIST;
    }
}
