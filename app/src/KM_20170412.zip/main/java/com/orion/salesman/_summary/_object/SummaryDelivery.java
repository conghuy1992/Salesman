package com.orion.salesman._summary._object;

import java.util.List;

/**
 * Created by maidinh on 11/8/2016.
 */
public class SummaryDelivery {
    int RESULT;
    List<Delivery>LIST;

    public int getRESULT() {
        return RESULT;
    }

    public void setRESULT(int RESULT) {
        this.RESULT = RESULT;
    }

    public List<Delivery> getLIST() {
        return LIST;
    }

    public void setLIST(List<Delivery> LIST) {
        this.LIST = LIST;
    }
}
